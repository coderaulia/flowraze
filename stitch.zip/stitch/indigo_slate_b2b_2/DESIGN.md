# Design System Specification: The Precision Architect

## 1. Overview & Creative North Star
This design system moves away from the "utility-first" aesthetic of standard B2B platforms toward a **"High-End Editorial"** experience. Our Creative North Star is **The Precision Architect**: a philosophy that treats data as a curated exhibition rather than a cluttered warehouse.

We break the "template" look by rejecting traditional structural lines and grids in favor of **Tonal Architecture**. By using intentional asymmetry, generous white space (inspired by high-end print magazines), and a sophisticated layering of surfaces, we create a CRM that feels authoritative, calm, and bespoke.

---

## 2. Colors & Surface Logic
The palette is rooted in a core of Slate neutrals with a singular, high-energy Indigo accent. This creates a "monastic-modern" vibe where the brand only speaks when it’s essential.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to define sections or regions. 
*   **Boundaries** must be defined solely through background color shifts (e.g., a `surface-container-low` sidebar against a `surface` background).
*   **Separation** is achieved through the Spacing Scale (typically `spacing-6` or `spacing-8`) to allow the eye to find the "natural break" without visual friction.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of premium materials.
- **Surface (`#f7f9fb`):** The base canvas.
- **Surface-Container-Low (`#f2f4f6`):** For structural sidebars or global navigation.
- **Surface-Container-Lowest (`#ffffff`):** For the primary cards and content modules. This creates a "lifted" feel against the background without requiring a heavy shadow.
- **Surface-Container-Highest (`#e0e3e5`):** For interactive hover states or "wells" that hold secondary data.

### The "Glass & Gradient" Rule
To inject "soul" into the CRM:
- **Primary CTAs:** Use a subtle linear gradient from `primary` (#3525cd) to `primary_container` (#4f46e5) at a 135-degree angle.
- **Floating Overlays:** For modals or popovers, use `surface_container_lowest` with a 80% opacity and a `backdrop-blur-xl` (20px) effect to create a sophisticated glassmorphism that integrates with the layout.

---

## 3. Typography
We use **Inter** as our typographic workhorse, but we treat it with editorial intent.

*   **Display (lg/md):** Used for high-level "At a Glance" metrics. Tighten letter-spacing (-0.02em) to give it a "machined" look.
*   **Headline (sm/md):** Use these for module titles. They provide the "Authoritative Voice."
*   **Body (md):** Our primary reading grade. Ensure a line-height of at least 1.6 for long-form CRM notes.
*   **Label (sm/md):** Use `on_surface_variant` (#464555) with 0.05em letter-spacing and uppercase transform for technical meta-data to distinguish it from narrative content.

---

## 4. Elevation & Depth
Hierarchy is conveyed through **Tonal Layering** rather than structural scaffolding.

### The Layering Principle
Depth is achieved by "stacking" the surface tiers. A `surface-container-lowest` card sitting on a `surface` background creates a soft, natural lift. This is the primary method of organization.

### Ambient Shadows
Shadows are reserved for elements that literally "float" (modals, dropdowns). 
- **Value:** `0 12px 32px -4px rgba(70, 69, 85, 0.06)`
- **Rule:** Shadows must be tinted with the `on-surface` color to mimic natural light, never pure black.

### The "Ghost Border" Fallback
If a border is required for accessibility (e.g., in high-contrast scenarios or complex data tables), use a **Ghost Border**: 
- **Value:** `outline-variant` (#c7c4d8) at **15% opacity**. 
- **Forbidden:** 100% opaque borders of any color.

---

## 5. Components

### Buttons
- **Primary:** Gradient fill (`primary` to `primary_container`), `rounded-md` (12px), and a subtle `inner-shadow` for tactile depth.
- **Secondary:** `surface_container_high` background with `on_surface` text. No border.
- **Tertiary:** Pure ghost style. Text-only with an Indigo `primary` underline on hover.

### Input Fields
- **Style:** Use `surface_container_low` as the field background. 
- **Interaction:** On focus, transition the background to `surface_container_lowest` and apply a 2px "Ghost Border" of the `primary` Indigo. 
- **Labels:** Use `label-md` placed strictly above the field, never as a placeholder.

### Cards & Modules
- **Padding:** Consistent `spacing-6` (2rem/32px) for internal padding.
- **Radius:** `rounded-lg` (1rem/16px) to provide a modern, friendly silhouette.
- **Separation:** Absolutely no divider lines. Use `spacing-4` or `spacing-6` vertical gaps to separate card headers from content.

### Data Visualization (Recharts)
- **Palette:** Use the `primary` (#3525cd) for the main data line. Use `secondary` (#58579b) and `tertiary` (#7e3000) for comparison sets.
- **Grid:** Hide all vertical grid lines. Horizontal grid lines should use the "Ghost Border" spec (10% opacity).

---

## 6. Do's and Don'ts

### Do
- **Do** use whitespace as a functional tool. If a screen feels "busy," add more `spacing-8` gaps before adding a line.
- **Do** layer a white card on a light-gray background to signify a workspace.
- **Do** use `Lucide` icons at 20px size for consistency, using the `outline` token color.

### Don't
- **Don't** use card borders. If the card isn't visible, your background color contrast is too low.
- **Don't** use high-saturation reds for errors unless it's a critical system failure. Use `error_container` with `on_error_container` for a softer, more professional warning.
- **Don't** cram the 12-column grid. Use "Editorial Offsets"—for example, leave the first 2 columns empty for a primary metric dashboard to create a sense of luxury and breathing room.